# CLAUDE.md — Global Rules for Flutter Payments App (BLoC & Riverpod)

[Full rules from the PDF go here]
